package com.example.thegreenguardian;

public class User {
    public String FullName,Email;

    public User(){

    }
    public User(String FullName,String Email)
    {
        this.FullName=FullName;
        this.Email=Email;
    }
}
